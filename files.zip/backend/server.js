import express from 'express';
import mongoose from 'mongoose';
import cors from 'cors';
import multer from 'multer';
import path from 'path';
import { fileURLToPath } from 'url';
import fs from 'fs';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Создать папки для загрузок, если их нет
['uploads', 'uploads/videos', 'uploads/posters'].forEach(dir => {
  if (!fs.existsSync(path.join(__dirname, dir))) {
    fs.mkdirSync(path.join(__dirname, dir), { recursive: true });
  }
});

const app = express();
app.use(cors());
app.use(express.json());
app.use('/uploads', express.static(path.join(__dirname, 'uploads')));

mongoose.connect('mongodb://localhost:27017/moviesite', { useNewUrlParser: true, useUnifiedTopology: true });

const movieSchema = new mongoose.Schema({
  title: String,
  description: String,
  videoPath: String,
  posterPath: String,
  createdAt: { type: Date, default: Date.now }
});
const Movie = mongoose.model('Movie', movieSchema);

const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    if (file.fieldname === 'video') cb(null, 'uploads/videos/');
    else cb(null, 'uploads/posters/');
  },
  filename: (req, file, cb) => cb(null, Date.now() + '-' + file.originalname)
});
const upload = multer({ storage });

app.post(
  '/api/movies',
  upload.fields([{ name: 'video', maxCount: 1 }, { name: 'poster', maxCount: 1 }]),
  async (req, res) => {
    try {
      const { title, description } = req.body;
      const videoPath = req.files['video'][0].path.replace(/\\/g, '/');
      const posterPath = req.files['poster'][0].path.replace(/\\/g, '/');
      const movie = new Movie({ title, description, videoPath, posterPath });
      await movie.save();
      res.status(201).json(movie);
    } catch (err) {
      res.status(500).json({ error: err.message });
    }
  }
);

app.get('/api/movies', async (req, res) => {
  const movies = await Movie.find().sort({ createdAt: -1 });
  res.json(movies);
});

app.listen(5000, () => console.log('Server started on http://localhost:5000'));