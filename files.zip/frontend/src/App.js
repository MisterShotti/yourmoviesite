import React, { useEffect, useState } from "react";
import MovieList from "./MovieList";
import AdminPanel from "./AdminPanel";

function App() {
  const [movies, setMovies] = useState([]);

  useEffect(() => {
    fetch("http://localhost:5000/api/movies")
      .then((r) => r.json())
      .then(setMovies);
  }, []);

  return (
    <div style={{ maxWidth: 900, margin: "0 auto", padding: 30 }}>
      <h1>Кинотеатр онлайн</h1>
      <AdminPanel onMovieAdded={(movie) => setMovies((m) => [movie, ...m])} />
      <MovieList movies={movies} />
    </div>
  );
}

export default App;