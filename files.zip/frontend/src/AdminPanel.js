import React, { useState } from "react";

export default function AdminPanel({ onMovieAdded }) {
  const [title, setTitle] = useState("");
  const [desc, setDesc] = useState("");
  const [video, setVideo] = useState(null);
  const [poster, setPoster] = useState(null);

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!title || !desc || !video || !poster) return;
    const data = new FormData();
    data.append("title", title);
    data.append("description", desc);
    data.append("video", video);
    data.append("poster", poster);

    const res = await fetch("http://localhost:5000/api/movies", {
      method: "POST",
      body: data,
    });
    if (res.ok) {
      const movie = await res.json();
      onMovieAdded(movie);
      setTitle(""); setDesc(""); setVideo(null); setPoster(null);
    }
  };

  return (
    <form onSubmit={handleSubmit} style={{ marginBottom: 30 }}>
      <h2>Добавить фильм</h2>
      <input
        placeholder="Название"
        value={title}
        onChange={e => setTitle(e.target.value)}
        required
      />
      <textarea
        placeholder="Описание"
        value={desc}
        onChange={e => setDesc(e.target.value)}
        required
      />
      <input
        type="file"
        accept="video/*"
        onChange={e => setVideo(e.target.files[0])}
        required
      />
      <input
        type="file"
        accept="image/*"
        onChange={e => setPoster(e.target.files[0])}
        required
      />
      <button type="submit">Загрузить</button>
    </form>
  );
}