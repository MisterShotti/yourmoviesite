import React from 'react';

export default function MoviePlayer({ movie, onClose }) {
  return (
    <div style={{ position: 'fixed', top: 0, left: 0, width: '100vw', height: '100vh', background: '#000b', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
      <div style={{ background: '#fff', padding: 20 }}>
        <h2>{movie.title}</h2>
        <video src={`http://localhost:5000/${movie.videoPath}`} controls width="600" />
        <p>{movie.description}</p>
        <button onClick={onClose}>Закрыть</button>
      </div>
    </div>
  );
}