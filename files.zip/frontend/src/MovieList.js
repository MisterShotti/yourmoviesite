import React, { useState } from "react";
import MoviePlayer from "./MoviePlayer";

export default function MovieList({ movies }) {
  const [selected, setSelected] = useState(null);

  return (
    <div>
      <h2>Фильмы</h2>
      <div style={{ display: "flex", flexWrap: "wrap", gap: 20 }}>
        {movies.map((movie) => (
          <div
            key={movie._id}
            style={{ cursor: "pointer" }}
            onClick={() => setSelected(movie)}
          >
            <img
              src={`http://localhost:5000/${movie.posterPath}`}
              alt={movie.title}
              width={200}
              style={{ borderRadius: 6, boxShadow: "0 2px 8px #0002" }}
            />
            <h3>{movie.title}</h3>
          </div>
        ))}
      </div>
      {selected && (
        <MoviePlayer movie={selected} onClose={() => setSelected(null)} />
      )}
    </div>
  );
}