import React from "react";

export default function MoviePlayer({ movie, onClose }) {
  return (
    <div
      style={{
        position: "fixed",
        top: 0, left: 0, width: "100vw", height: "100vh",
        background: "#000c", display: "flex", alignItems: "center", justifyContent: "center",
        zIndex: 10
      }}
    >
      <div style={{ background: "#fff", padding: 20, borderRadius: 8, maxWidth: 800 }}>
        <h2>{movie.title}</h2>
        <video src={`http://localhost:5000/${movie.videoPath}`} controls width="700" />
        <p>{movie.description}</p>
        <button onClick={onClose}>Закрыть</button>
      </div>
    </div>
  );
}